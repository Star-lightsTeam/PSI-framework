from sklearn.decomposition import PCA
from torch import optim
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import torch
from sklearn.model_selection import train_test_split
import torch.nn as nn
from torch.optim import Adam

class RegressionNN(nn.Module):
    def __init__(self, input_size):
        super(RegressionNN, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128,64)
        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = self.fc4(x)
        return x


class UpliftNet(nn.Module):
    def __init__(self, input_size, output_size):
        super(UpliftNet, self).__init__()
        self.fc1 = nn.Linear(input_size, 200)
        self.relu = nn.LeakyReLU(0.2)
        self.fc2 = nn.Linear(200, output_size)

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.fc2(x)
        return x

    
class RegressionNN_2(nn.Module):
    def __init__(self, input_size):
        super(RegressionNN_2, self).__init__()
        self.fc1 = nn.Linear(input_size, 32)
        self.fc2 = nn.Linear(32, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

    
    
class RegressionNN_3(nn.Module):
    def __init__(self, input_size):
        super(RegressionNN_3, self).__init__()
        self.fc1 = nn.Linear(input_size, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

    
    
class UpliftNet(nn.Module):
    def __init__(self, input_size, output_size):
        super(UpliftNet, self).__init__()
        self.fc1 = nn.Linear(input_size, 200)
        self.relu = nn.LeakyReLU(0.2)
        self.fc2 = nn.Linear(200, output_size)

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.fc2(x)
        return x

    
    
class RegressionNN_5(nn.Module):
    def __init__(self, input_size):
        super(RegressionNN_5, self).__init__()
        self.fc1 = nn.Linear(input_size, 256)
        self.fc2 = nn.Linear(256,128)
        self.fc3 = nn.Linear(128, 64)
        self.fc4 = nn.Linear(64, 32)
        self.fc5 = nn.Linear(32,1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        x = torch.relu(self.fc4(x))
        x = self.fc5(x)
        return x
    
def pca_process(data,yuzhi=0.7):
    for n_component in range(50,500):
        pca = PCA(n_component)
        X_pca = pca.fit_transform(data)
        if pca.explained_variance_ratio_.sum() > yuzhi:
            print(n_component,pca.explained_variance_ratio_.sum())
            return X_pca,n_component

def net_shenwei(data,output_size):
    input_size = 5
    output_size = output_size
    model = UpliftNet(input_size,output_size)
    batch_size = 10
    X = torch.tensor(np.array(data),dtype=torch.float32)
    x_expanded = model(X)
    return x_expanded.detach().numpy()

def evalute(y_test,outputs_test):
    mae = torch.mean(abs(10**y_test-10**outputs_test))
    mse = torch.mean((10**y_test-10**outputs_test)**2)
    sse = torch.sum((10**y_test-10**outputs_test)**2)
    sst = torch.sum((10**outputs_test-10**torch.mean(y_test))**2)
    r2 = 1 - sse/sst
    print("MSE:{}\tMAE:{}\tR2:{}".format(mse,mae,r2))

